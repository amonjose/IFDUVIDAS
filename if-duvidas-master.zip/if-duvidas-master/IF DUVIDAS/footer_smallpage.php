<?php  echo '

<div class="ui bottom attached header" id="rodape_bug" style="position: fixed">
    <div class="ui list horizontal alligned">
      <div class="item">
        <i class="users icon"></i>
        <div class="content">
          2INFO2
        </div>
      </div>
      <div class="item">
        <i class="marker icon"></i>
        <div class="content">
          BR 280, Araquari
        </div>
      </div>
      <div class="item">
        <i class="mail icon"></i>
        <div class="content">
          <a href="mailto:">if-duvida@exemplo.com</a>
        </div>
      </div>
      <div class="item">
        <i class="linkify icon"></i>
        <div class="content">
          <a href="">if-duvida.com</a>
        </div>
      </div>
    </div>
  </div>
 
'?>