<?php echo '
<title>IF Duvidas</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="semantic/semantic.js"></script>
<script type="text/javascript" src="semantic/components/dropdown.js"></script>
<link rel="stylesheet" type="text/css" href="semantic/components/dropdown.css">
<script type="text/javascript" src="script.js"></script>
<link rel="stylesheet" type="text/css" href="css.css">

';
?>