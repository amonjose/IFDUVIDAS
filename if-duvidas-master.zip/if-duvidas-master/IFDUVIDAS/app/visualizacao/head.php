<?php echo '
<title>IF Duvidas</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="../visualizacao/semantic/semantic.css">
<script type="text/javascript" src="../visualizacao/jquery.js"></script>
<script type="text/javascript" src="../visualizacao/semantic/semantic.js"></script>
<script type="text/javascript" src="../visualizacao/semantic/components/dropdown.js"></script>
<link rel="stylesheet" type="text/css" href="../visualizacao/semantic/components/dropdown.css">
<script type="text/javascript" src="../visualizacao/script.js"></script>
<link rel="stylesheet" type="text/css" href="../visualizacao/css.css">

';
?>