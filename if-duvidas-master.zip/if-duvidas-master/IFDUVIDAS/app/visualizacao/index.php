<!DOCTYPE html>
<html>
<head>
<?php include'head.php' ?>

</head>
<body>

<?php include'menu.php' ?>

  <div class="ui grid">
      <div class="one wide column"></div>
      <div class="fourteen wide column" id="imagem"><img class="ui fluid image" src="../visualizacao/media/duvida_menina.jpg"></div>
      <div class="one wide column"></div>

      <div class="six wide column"></div>
      <div class="four wide column">
        <h1>Qual a sua dúvida?</h1>
          <div class="ui icon input">
              <input type="text" placeholder="Pergunta aí fera...">
          </div>
      </div>

          <div class="six wide column"></div>
  </div>


    <div class="sixteen wide column">



    </div>









  <div class="ui grid" id="grid_estatistica">
    <div class="four wide column"></div>
    <div class="eight wide column">
     <div class="ui three column very relaxed grid">
      <div class="column">
       <div class="ui center aligned segment">
        <div class="text">
          Ultimas perguntas:
          </br>
          <b>EXEMPLO</b>
        </div>
      </div>
    </div>

    <div class="column">
     <div class="ui center aligned segment">
      <div class="text">
          Perguntas mais curtidas:
          </br>
          <b>EXEMPLO</b>
        </div>
    </div>
  </div>

  <div class="column">
   <div class="ui center aligned segment">
    <div class="text">
          Perguntas respondidas:
          </br>
          <b>EXEMPLO</b>
        </div>
  </div>
</div>
</div>
</div>
<div class="four wide column"></div>
</div>





</body>



</html>
